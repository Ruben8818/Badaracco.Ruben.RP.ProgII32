
package parcialprogrrubenbadaracco321;


public class Explorador extends Superviviente implements Asignable {
    private final int valorResistencia;

    public Explorador( String codigo, String nombre, NivelExperiencia nivel, boolean estadoDisponibilidad,int valorResistencia) {
        super(codigo, nombre, nivel, estadoDisponibilidad);
        validarResistencia(valorResistencia);
        this.valorResistencia = valorResistencia;
    }
    private void validarResistencia(int resistencia){
        if(resistencia < 0 ){
            throw new IllegalArgumentException("Resistencia invalida");
        }
    }

    public int getValorResistencia() {
        return valorResistencia;
    }

    @Override
    public String toString() {
        return "Explorador" + super.toString() + "valorResistencia=" + valorResistencia + '}';
    }

    @Override
    protected int calcularAptitud() {
        return valorResistencia * 2;
    }

    @Override
    public String asignarTarea() {
        return "Se asigno a " + getNombre() +" la tarea: Mision de apoyo.";
    }
    }
    
    
    


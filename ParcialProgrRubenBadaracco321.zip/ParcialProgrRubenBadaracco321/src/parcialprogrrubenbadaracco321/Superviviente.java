
package parcialprogrrubenbadaracco321;

import java.util.Objects;


public abstract class Superviviente {
    private final String codigo;
    private final String nombre;
    private NivelExperiencia nivel;
    private final boolean estadoDisponibilidad;

    public Superviviente(String codigo, String nombre, NivelExperiencia nivel, boolean estadoDisponibilidad) {
        validarParametro(codigo);
        validarParametro(nombre);
        Objects.requireNonNull(nivel);
        Objects.requireNonNull(estadoDisponibilidad);
        this.codigo = codigo;
        this.nombre = nombre;
        this.nivel = nivel;
        this.estadoDisponibilidad = estadoDisponibilidad;
    }
    private void validarParametro(String parametro){
        if(parametro == null || parametro.isBlank()){
            throw new IllegalArgumentException("¨Parametro invalido");
        }
    }
    
    
    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public NivelExperiencia getNivel() {
        return nivel;
    }

    public boolean isEstadoDisponibilidad() {
        return estadoDisponibilidad;
    }

    @Override
    public String toString() {
        return "Superviviente{" + "codigo=" + codigo + ", nombre=" + nombre + ", nivel=" + nivel + ", estadoDisponibilidad=" + estadoDisponibilidad + '}';
    }
    
    protected abstract int calcularAptitud();

    @Override
    public int hashCode() {
       return Objects.hash(codigo, nombre);
    }

    @Override
    public boolean equals(Object obj) {
        if(obj == null || !(obj instanceof Superviviente s)){
            return false;
        }
        return codigo.equals(s.codigo) &&
                nombre.equals(s.nombre);
    }
    
    
}


package parcialprogrrubenbadaracco321;


public interface Capacitable {
    String capacitar();
}

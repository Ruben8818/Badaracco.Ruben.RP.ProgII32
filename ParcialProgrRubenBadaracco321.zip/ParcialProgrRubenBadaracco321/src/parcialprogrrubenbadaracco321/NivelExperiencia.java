
package parcialprogrrubenbadaracco321;


public enum NivelExperiencia {
    NOVATO,
    INTERMEDIO,
    EXPERTO
}


package parcialprogrrubenbadaracco321;


public class Medico extends Superviviente implements Capacitable{
    private final int valorConocimiento;

    public Medico( String codigo, String nombre, NivelExperiencia nivel, boolean estadoDisponibilidad,int valorConocimiento) {
        super(codigo, nombre, nivel, estadoDisponibilidad);
        validarConocimiento(valorConocimiento);
        this.valorConocimiento = valorConocimiento;
    }
    
    private void validarConocimiento(int conocimiento){
        if(conocimiento < 0 ){
            throw new IllegalArgumentException("RConocimiento invalido");
        }
    }

    public int getValorConocimiento() {
        return valorConocimiento;
    }

    @Override
    public String toString() {
        return "Medico" + super.toString() + "valorConocimiento=" + valorConocimiento + '}';
    }

    @Override
    protected int calcularAptitud() {
        return valorConocimiento + 10;
    }

    @Override
    public String capacitar() {
        return  "Se capacito a " + getNombre() + "(" + getCodigo() + ")";
    }
    
}


package parcialprogrrubenbadaracco321;


public class SupervivienteDuplicadoException extends Exception {
    private static final String MESSAGE = "Ya existe superviviente en la lista";

    public SupervivienteDuplicadoException() {
        super(MESSAGE);
    }

    public SupervivienteDuplicadoException(String mensaje) {
        super(mensaje);
    }
    
    
    
}

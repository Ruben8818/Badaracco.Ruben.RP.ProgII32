
package parcialprogrrubenbadaracco321;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class Refugio {
    private final String nombre;
    private List<Superviviente> supervivientes;

    public Refugio(String nombre) {
        validarNombre(nombre);
        this.nombre = nombre;
        this.supervivientes = new ArrayList<>();
    }
    
    private void validarNombre(String nombre){
        if(nombre == null || nombre.isBlank()){
            throw new IllegalArgumentException("Nombre invalido");
        }
    }
    
    public void agregarSuperviviente(Superviviente superviviente)throws SupervivienteDuplicadoException{
        Objects.requireNonNull(superviviente);
        validarSupervivienteDuplicado(superviviente);
        supervivientes.add(superviviente);
    }
    
    private void validarSupervivienteDuplicado(Superviviente superviviente) throws SupervivienteDuplicadoException {
        if(supervivientes.contains(superviviente)){
            throw new SupervivienteDuplicadoException("Ya existe superiviente con codigo " + superviviente.getCodigo() + " y nombre " + superviviente.getNombre());
        }
    }
    
    public ArrayList<Superviviente> obtenerSupervivientes(){
        return new ArrayList<Superviviente>(supervivientes);
    }
    
    public ArrayList<Superviviente> filtrarPorNivel(NivelExperiencia nivel){
        ArrayList<Superviviente> copiaFiltrada = new ArrayList<>();
        for(Superviviente s : supervivientes){
            if(s.getNivel().equals(nivel)){
                copiaFiltrada.add(s);
            }
        }
        return copiaFiltrada;
    }
    
    public ArrayList<Superviviente> obtenerDisponiblesConAptitudMinima(int minimo){
       validarMinimo(minimo);
        ArrayList<Superviviente> copiaFiltrada = new ArrayList<>();
        for(Superviviente s : supervivientes){
            if(s.calcularAptitud() >= minimo){
                copiaFiltrada.add(s);
            }
        }
        return copiaFiltrada;
    }
    
    private void validarMinimo(int minimo){
        if(minimo < 8){
            throw new IllegalArgumentException("Minimo invalido");
        }
    }
    
}


package parcialprogrrubenbadaracco321;


public interface Asignable {
    String asignarTarea();
}

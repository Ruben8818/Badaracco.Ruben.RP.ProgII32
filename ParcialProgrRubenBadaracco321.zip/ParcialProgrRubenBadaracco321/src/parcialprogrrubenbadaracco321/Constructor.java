
package parcialprogrrubenbadaracco321;


public class Constructor extends Superviviente implements Asignable, Capacitable {
    private final int valorHabilidadTec;

    public Constructor( String codigo, String nombre, NivelExperiencia nivel, boolean estadoDisponibilidad,int valorHabilidadTec) {
        super(codigo, nombre, nivel, estadoDisponibilidad);
        validarHabilidad(valorHabilidadTec);
        this.valorHabilidadTec = valorHabilidadTec;
    }
    
    
    private void validarHabilidad(int habilidad){
        if(habilidad < 0 ){
            throw new IllegalArgumentException("Habilidad invalida");
        }
    }

    public int getValorHabilidadTec() {
        return valorHabilidadTec;
    }

    @Override
    public String toString() {
        return "Constructor " + super.toString() + "valorHabilidadTec=" + valorHabilidadTec + '}';
    }

    @Override
    protected int calcularAptitud() {
        return valorHabilidadTec * 3;
    }

    @Override
    public String asignarTarea() {
        return "Se asigno a " + getNombre() +" la tarea: Mision de apoyo.";
    }

    @Override
    public String capacitar() {
       return  "Se capacito a " + getNombre() + "(" + getCodigo() + ")";
    }
    
}
